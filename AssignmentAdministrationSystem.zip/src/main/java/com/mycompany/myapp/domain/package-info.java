/**
 * JPA domain objects.
 */
package com.mycompany.myapp.domain;
